import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NgForm } from '@angular/forms';

import { Observable, catchError, map, of, tap } from 'rxjs';
import { AuthenticationResponse } from './app/authentication-response';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private loginUrl = 'http://localhost:8080/login'; // Update with your backend login URL
  private tokenKey = 'token';

  constructor(private http: HttpClient) { }
  username1: string='';
  
  login(username: string, password: string): Observable<AuthenticationResponse> {
    // Check if token is already present
    const existingToken = this.getToken();
    if (existingToken) {
      // Token exists, no need to log in again, return the actual token and message
      return of({ token: existingToken, message: localStorage.getItem('message') || '' });
    }
  
    // Return the HTTP request observable
    return this.http.post<AuthenticationResponse>(this.loginUrl, { username, password }).pipe(
      map(response => {
        localStorage.setItem(this.tokenKey, response.token);
        localStorage.setItem('message', response.message.toString()); // Store message in localStorage
        console.log('Token:', response.token);
        return response;
      }),
      catchError(error => {
        // Handle errors here (e.g., display error message)
        console.error('Login failed:', error);
        throw error; // Rethrow the error
      })
    );
  }
  
  getToken(): string {
    const token = localStorage.getItem(this.tokenKey);
    return token !== null ? token : ''; // Return an empty string if token is null
    
  }
  
  logout(): void {
    localStorage.removeItem(this.tokenKey);

  }

  getHeaders(): HttpHeaders {
    const token = this.getToken();
    if (!token) {
      return new HttpHeaders({
        'Content-Type': 'application/json'
      });
    }

    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token
    });
  }
}
