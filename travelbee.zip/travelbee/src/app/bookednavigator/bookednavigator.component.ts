import { Component } from '@angular/core';
import { NavigatorService } from '../navigator.service';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-bookednavigator',
  templateUrl: './bookednavigator.component.html',
  styleUrl: './bookednavigator.component.css'
})
export class BookednavigatorComponent {
  alertWithSucess()
  {
    Swal.fire("Cancelled....",'Cancelled Successfully','success');
  }
  confirmation: string = '';
  booking: any = {};
  deleteButtonDisabled: boolean = false;
  deleteButtonMessage: string = '';
 
  constructor(private bookingService: NavigatorService, private route: ActivatedRoute, private router: Router) {}
 
  ngOnInit() {
    this.confirmation = this.route.snapshot.params['conformation'];
    this.bookingService.getBookingbyconformationcode(this.confirmation).subscribe(
      data => {
        this.booking = data;
      },
      error => console.log(error)
    );
  }
 
  cancelBooking(bookingId: number) {
    // Disable the delete button
    this.deleteButtonDisabled = true;
 
    this.bookingService.cancelBooking(bookingId).subscribe(
      data => {
        console.log(data);
        this.deleteButtonMessage = 'Booking deleted successfully.';
      },
      error => {
        console.error(error);
        this.deleteButtonMessage = 'Error deleting booking.';
      }
    );
  }
  navigateToAvailableNavigators() {
   
    if (this.booking && this.booking.touristEmail) {
      this.router.navigate(['avilablenavigators'], { queryParams: { email: this.booking.touristEmail },skipLocationChange: true });
     
    } else {
     
      console.error('Tourist email is not available.');
    }
  }
  
 
   
 
}
