import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookednavigatorComponent } from './bookednavigator.component';

describe('BookednavigatorComponent', () => {
  let component: BookednavigatorComponent;
  let fixture: ComponentFixture<BookednavigatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BookednavigatorComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BookednavigatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
