import { AuthService } from './../../auth.service';

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { response } from 'express';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
 email:string="";
  constructor(private router:Router,private authService:AuthService){}
  isActive=true;
  isError=false;
  signup()
  {
    this.router.navigate(["signup"]);
    console.log("hello")
    this.isActive=false;
  }

  
login(username: string, password: string): void {
  console.log(username)
  this.authService.login(username, password)
    .subscribe( response => {
      // Handle successful login
      console.log('Login successful:', response);
      // Determine the route based on the response message
      console.log(response)
      if (response.message .toString()=== 'ADMIN') {
        this.isActive=false;
        this.router.navigate(['/addnavigator']);
      } else if (response.message.toString()=== 'USER') {
        this.isActive=false;
        console.log(response)
        console.log("trgr")
        this.router.navigate(['/avilablenavigators'],{ queryParams: { email: username } ,skipLocationChange:true});
      } else {
        
        console.log("hello surya")
        // Handle unexpected response message
        console.error('Unexpected response message:', response.message);
      }
    },
    error => {
      this.isError=true
      // Handle login error
      console.error('invalid details:', error);
      // Optionally, display error message to the user
    }
  );
}
  service()
  {
    this.isActive=false;
    console.log("howw")
  } 
  
  contact()
  {
    this.isActive=false;
  }
  
  aboutus()
  {
    this.isActive=false;
  }

}
