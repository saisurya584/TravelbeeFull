import { Component } from '@angular/core';
import { NavigatorService } from '../navigator.service';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent {
  
  alertWithSucess()
  {
    Swal.fire("Cancelled.....",'Booking cancelled successfully','success');
  }
  email: string = '';
  bookings: any[] = [];
 
  constructor(private bookingService: NavigatorService, private route: ActivatedRoute, private router: Router) {}
 
  ngOnInit() {
    // Retrieve email from query parameters
    this.route.queryParams.subscribe(params => {
      this.email = params['email'] || '';
 
      // After retrieving the email, you can use it to fetch bookings
      this.refreshBookings();
    });
  }
 
  getBookings() {
    if (this.email) {
      this.bookingService.getBookingsByTouristEmail(this.email).subscribe(
        data => {
          console.log(data)
          this.bookings = data;
        },
        error => {
          console.error(error);
          // Handle error
        }
      );
    }
  }
 
  refreshBookings() {
    // Call getBookings to refresh the bookings based on the current email
    this.getBookings();
  }
 
  navigateToAvailableNavigators() {
    // Navigate to the "Available Navigators" component with the email parameter
    this.router.navigate(['avilablenavigators'], { queryParams: { email: this.email }, skipLocationChange: true });
  }
 
  cancelBooking(bookingId: number) {
    // Disable the cancel button
    const bookingIndex = this.bookings.findIndex(booking => booking.bookingId === bookingId);
    this.bookings[bookingIndex].cancelButtonDisabled = true;
 
    this.bookingService.cancelBooking(bookingId).subscribe(
      data => {
        console.log(data);
        // Update UI with success message
        //this.bookings[bookingIndex].cancelButtonMessage = 'Booking canceled successfully.';
        this.alertWithSucess();
      },
      error => {
        console.error(error);
        // Update UI with error message
        this.bookings[bookingIndex].cancelButtonMessage = 'Error canceling booking.';
      }
    );
  }
 
  isCancelButtonEnabled(startDate: any): boolean {
    if (!(startDate instanceof Date)) {
      // If startDate is not a Date object, return false
      return false;
    }
 
    const currentDate = new Date();
    // Allow canceling before the start date
    return currentDate.getTime() < startDate.getTime();
  }
 
 
}