
export interface NavigatorResponseDto {
    navigatorId?: number;
    place: string;
    navigatorName: string;
    navigatorEmail: string;
    contactNumber: string;
    aadharNumber: string;
    price: number;
    photo: File;
  }
  
