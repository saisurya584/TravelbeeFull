import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule, NgControl, ReactiveFormsModule } from '@angular/forms';
import { SignupComponent } from './signup/signup.component';
import { AddNavigatorComponent } from './add-navigator/add-navigator.component';
import { AllnavigatorsComponent } from './allnavigators/allnavigators.component';
import { AvilablenavigatorsComponent } from './avilablenavigators/avilablenavigators.component';
import { BookingComponent } from './booking/booking.component';
import { SavebookingComponent } from './savebooking/savebooking.component';
import { BookednavigatorComponent } from './bookednavigator/bookednavigator.component';
import { UpdateNavigatorComponent } from './update-navigator/update-navigator.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { PopupComponent } from './popup/popup.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SignupComponent,
    AddNavigatorComponent,
    AllnavigatorsComponent,
    AvilablenavigatorsComponent,
    BookingComponent,
    SavebookingComponent,
    BookednavigatorComponent,
    UpdateNavigatorComponent,
    PopupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
