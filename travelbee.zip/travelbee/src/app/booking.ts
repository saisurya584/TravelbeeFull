export interface Booking {
        bookingId: number;
        startDate: Date;
        endDate: Date;
        touristFullName: string;
        contactNumber: string;
        touristEmail: string;
        numOfAdults: number;
        numOfChildren: number;
        totalNumOfTourists: number;
        bookingConfirmationCode: string;
      }

