import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { NavigatorService } from '../navigator.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css'
})
export class SignupComponent implements OnInit {

  
 
  

  isFirstName=false;
islastName=false;
isEmail=false;
istrue=true;
isPassword=false;
successMessage:string| null = null;
errorMessage:string | null = null
user: User = {
  firstName: '',
  lastName: '',
  username: '',
  password: '',
  role: ''
  
};

firstName: any;
alertWithSucess()
    {
      Swal.fire("Thank you..",'Successfully Registered','success');
    }
constructor(private userService: NavigatorService,private router:Router) {}
  ngOnInit(): void {
    
  }
back()
  {
    this.router.navigate(['/home'])
  }
register(): void {

  console.log(this.user)
  if(this.user.firstName.length<3 )
  {
      this.isFirstName=true
  }

  if(!this.user.firstName.match("[A-Za-z]"))
  {
    this.isFirstName=true
    this.istrue=false;
  }
  if(this.user.lastName.length<3)
  {
      this.islastName=true
      this.istrue=false;
  }
  if(!this.user.lastName.match("[A-Za-z]"))
  {
    this.islastName=true;
    this.istrue=false;
  }
  if(!this.user.username.match("[A-Za-z0-9]{4,20}@gmail.com$"))
  {
     this.isEmail=true;
     this.istrue=false;
  }
  if(!this.user.password.match("^[A-Z]+[a-zA-Z0-1!@#$%Z^&*]{8,20}"))
  {
    this.isPassword=true;
    this.istrue=false;
  }
 if(this.istrue){
  this.userService.register(this.user)
    .subscribe(response => {
      // Handle the response here
   
      this.alertWithSucess();
     
      this.successMessage = 'Registration successful!';
     
      this.errorMessage = null;
      console.log(response);
    },error => {
      // Handle error
      this.errorMessage = 'Registration failed. Please try again.';
      this.successMessage = null;
      
}
 
);

}
 
}





}
