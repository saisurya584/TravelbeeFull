import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { BookingDto, NavigatorDto } from './navigator';
import { Navigators } from './navigators';
import { NavigatorResponseDto } from './navigator-response-dto';
import { AuthenticationResponse } from './authentication-response';

import { User } from './user';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class NavigatorService {
  private apiUrl = 'http://localhost:8080';

  constructor(private http: HttpClient,private authService: AuthService) {}

  getAllPlaces(): Observable<string[]> {
    const url = `${this.apiUrl}/place`; // Assuming your endpoint for getting all places is '/place'
   
    // Set the headers with the authorization token
    const headers = this.authService.getHeaders();
 
    return this.http.get<string[]>(url, { headers });
  }

  addNavigator(formData: FormData): Observable<any> {
    const url = `${this.apiUrl}/addnavigator`;
    return this.http.post(url, formData);
  }
  
  // getAllNavigators(): Observable<NavigatorDto[]> {
  //   return this.http.get<NavigatorDto[]>(`${this.apiUrl}/allnavigators`);
  // }
 
  getAllNavigators(): Observable<NavigatorDto[]> {
    const headers = this.authService.getHeaders();
    return this.http.get<NavigatorDto[]>(`${this.apiUrl}/allnavigators`, { headers });
  }

  // getNavigatorByNavigatorId(navigatorId: number) {
  //   return this.http.get(`${this.apiUrl}/navigator/${navigatorId}`);
  // }

  // updateNavigator(navigatorId: number, formData: FormData) {
  //   return this.http.put(`${this.apiUrl}/update/${navigatorId}`, formData);
  // }
  // deleteNavigator(navigatorId: number) {
  //   return this.http.delete(`${this.apiUrl}/deletenavigator/${navigatorId}`);
  // }
  getNavigatorByNavigatorId(navigatorId: number): Observable<any> {
    const headers = this.authService.getHeaders();
    return this.http.get(`${this.apiUrl}/navigator/${navigatorId}`, { headers });
  }

  updateNavigator(navigatorId: number, formData: FormData): Observable<any> {
  //  const headers = this.authService.getHeaders();
    return this.http.put(`${this.apiUrl}/update/${navigatorId}`, formData);
  }

  deleteNavigator(navigatorId: number): Observable<any> {
    const headers = this.authService.getHeaders();
    return this.http.delete(`${this.apiUrl}/deletenavigator/${navigatorId}`, { headers });
  }

  // getAvailableNavigators(startDate: string, endDate: string, place: string): Observable<NavigatorDto[]> {
  //   const params = new HttpParams()
  //     .set('startDate', startDate)
  //     .set('endDate', endDate)
  //     .set('place', place);

  //   return this.http.get<NavigatorDto[]>(`${this.apiUrl}/availablenavigators`, { params });
  // }

  // saveBooking(navigatorId: number, booking: any): Observable<any> {
    
  //   const url = `${this.apiUrl}/navigator/${navigatorId}/booking`;

    
  //   return this.http.post(url, booking, { responseType: 'text' });
  // }

  // deleteBiooking(bookingId: number) {
  //   return this.http.delete(`${this.apiUrl}/booking/${bookingId}/delete`);
  // }

  // getBookingbyconformationcode(conformation: string): Observable<BookingDto[]> {
  //   const url = `${this.apiUrl}/confirmation/${conformation}`;
  //   return this.http.get<BookingDto[]>(url);
  // }

  // cancelBooking(bookingId: number): Observable<void> {
  //   const url = `${this.apiUrl}/booking/${bookingId}/delete`;
  //   return this.http.delete<void>(url);
  // }
  // getBookingsByTouristEmail(email: string): Observable<any[]> {
  //   const url = `${this.apiUrl}/tourist/${email}/bookings`;
  //   return this.http.get<any[]>(url);
  // }
  getAvailableNavigators(startDate: string, endDate: string, place: string): Observable<NavigatorDto[]> {
    const params = new HttpParams()
      .set('startDate', startDate)
      .set('endDate', endDate)
      .set('place', place);

    const headers = this.authService.getHeaders();
    return this.http.get<NavigatorDto[]>(`${this.apiUrl}/availablenavigators`, { params, headers });
  }

  saveBooking(navigatorId: number, booking: any): Observable<any> {
    const url = `${this.apiUrl}/navigator/${navigatorId}/booking`;
    const headers = this.authService.getHeaders();
    return this.http.post(url, booking, { headers, responseType: 'text' });
  }

  deleteBiooking(bookingId: number): Observable<any> {
    const headers = this.authService.getHeaders();
    return this.http.delete(`${this.apiUrl}/booking/${bookingId}/delete`, { headers });
  }

  getBookingbyconformationcode(conformation: string): Observable<BookingDto[]> {
    const url = `${this.apiUrl}/confirmation/${conformation}`;
    const headers = this.authService.getHeaders();
    return this.http.get<BookingDto[]>(url, { headers });
  }

  cancelBooking(bookingId: number): Observable<void> {
    const url = `${this.apiUrl}/booking/${bookingId}/delete`;
    const headers = this.authService.getHeaders();
    return this.http.delete<void>(url, { headers });
  }

  getBookingsByTouristEmail(email: string): Observable<any[]> {
    const url = `${this.apiUrl}/tourist/${email}/bookings`;
    const headers = this.authService.getHeaders();
    return this.http.get<any[]>(url, { headers });
  }
  // signup(data: any): Observable<any> {
  //   return this.http.post(`${this.apiUrl}/signup`, data);
  // }
  register(user: User): Observable<AuthenticationResponse> {
    return this.http.post<AuthenticationResponse>(`${this.apiUrl}/register`, user);
  }


}


  
  // login(email: string, password: string, role: string): Observable<string> {
  //   const params = new HttpParams()
  //     .set('email', email)
  //     .set('password', password)
  //     .set('role', role);

  //   return this.http.get<string>(`${this.apiUrl}/logining`, { params });
  // } 
  // private loginUrl = 'http://localhost:8080/login';
  // login(username: string, password: string): Observable<AuthenticationResponse> {
  //   return this.http.post<AuthenticationResponse>(this.loginUrl, { username, password });
  // }
