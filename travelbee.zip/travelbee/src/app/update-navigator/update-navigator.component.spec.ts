import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateNavigatorComponent } from './update-navigator.component';

describe('UpdateNavigatorComponent', () => {
  let component: UpdateNavigatorComponent;
  let fixture: ComponentFixture<UpdateNavigatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UpdateNavigatorComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UpdateNavigatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
