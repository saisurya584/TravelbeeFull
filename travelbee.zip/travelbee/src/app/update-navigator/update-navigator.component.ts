import { Component } from '@angular/core';
import { NavigatorService } from '../navigator.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-update-navigator',
  templateUrl: './update-navigator.component.html',
  styleUrl: './update-navigator.component.css'
})
export class UpdateNavigatorComponent {

  navigatorId: number = 0; // Initialize navigatorId
  navigator: any = {}; // Update this to match the structure of your Navigator model
  photo: File | null = null;
 
  constructor(private navigatorService: NavigatorService, private route: ActivatedRoute, private router: Router) {}
 
  ngOnInit() {
    this.navigatorId = this.route.snapshot.params['navigatorId'];
    this.navigatorService.getNavigatorByNavigatorId(this.navigatorId).subscribe(
      data => {
        this.navigator = data;
      },
      error => console.log(error)
    );
  }
  onFileChange(event: any) {
    const files = event.target.files;
    if (files && files.length > 0) {
      this.photo = files[0];
    }
  }
 
  updateNavigator() {
    const formData = new FormData();
    formData.append('place', this.navigator.place);
    formData.append('navigatorName', this.navigator.navigatorName);
    formData.append('navigatorEmail', this.navigator.navigatorEmail);
    formData.append('contactNumber', this.navigator.contactNumber);
    formData.append('aadharNumber', this.navigator.aadharNumber);
    formData.append('Price', this.navigator.price.toString());
 
    if (this.photo) {
      formData.append('photo', this.photo);
    }
 
    this.navigatorService.updateNavigator(this.navigatorId, formData).subscribe(
      (response) => {
        // Handle success response
        console.log(response);
        this.router.navigate(['/allnavigators']);
      },
      (error) => {
        // Handle error response
        console.log(error);
        console.error(error);
      }
    );
  }
  navigateToAllNavigators() {
    this.router.navigate(['allnavigators'],{skipLocationChange: true });
  }
}


