import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NavigatorService } from '../navigator.service';
import { formatDate } from '@angular/common';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-savebooking',
  templateUrl: './savebooking.component.html',
  styleUrl: './savebooking.component.css'
})
export class SavebookingComponent {
   
  
navigatorId: number = 0;
 
  booking = {
    startDate: '',
    endDate: '',
    touristFullName: '',
    contactNumber: '',
    touristEmail: '',
    numOfAdults: 0,
    numOfChildren: 0,
 
  };
 
  responseFromServer: string = '';
  isBookingSaved: boolean = false; // Add this flag
 
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private bookingService: NavigatorService
  ) {}
 
  ngOnInit() {
    const navigatorIdParam = this.route.snapshot.paramMap.get('navigatorId');
    if (navigatorIdParam !== null) {
      this.navigatorId = +navigatorIdParam;
        const queryParams = this.route.snapshot.queryParams;
        this.booking.startDate = queryParams['startDate'] || '';
        this.booking.endDate = queryParams['endDate'] || '';
        this.booking.touristEmail = queryParams['email'] || ''; // Assuming the parameter name is 'email'
    } else {
      // Handle the case where navigatorId is null
    }
  }
 
  // Function to format date to local date string
  formatDateToLocaleString(date: Date): string {
    return formatDate(date, 'yyyy-MM-dd', 'en-US'); // Adjust the format as needed
  }
 
  saveBooking() {
    // Convert start and end dates to local date string format
    this.booking.startDate = this.formatDateToLocaleString(new Date(this.booking.startDate));
    this.booking.endDate = this.formatDateToLocaleString(new Date(this.booking.endDate));
 
    this.bookingService.saveBooking(this.navigatorId, this.booking).subscribe(
      (data) => {
        console.log('Success:', data);

      
    
        this.responseFromServer = data;
       
  
    Swal.fire(data,'Booked successfully','success');
  
        
       // this.isBookingSaved = true; // Set the flag to true after successful booking
      },
      (error) => {
        console.error('Error:', error);
        // Handle error, e.g., show error message
      }
    );
  }
 
  bookingDetails() {
    this.router.navigate(["currentbookednavigator",this.responseFromServer],{ skipLocationChange: true });
  }
  navigateToAvailableNavigators() {
      this.router.navigate(['avilablenavigators'], { queryParams: { email: this.booking.touristEmail },skipLocationChange: true });      
    }
}