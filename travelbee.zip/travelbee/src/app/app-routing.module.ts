

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ServiceComponent } from './service/service.component';
import { HomeComponent } from './home/home.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactComponent } from './contact/contact.component';
import { SignupComponent } from './signup/signup.component';
import { AddNavigatorComponent } from './add-navigator/add-navigator.component';
import { AllnavigatorsComponent } from './allnavigators/allnavigators.component';
import { AvilablenavigatorsComponent } from './avilablenavigators/avilablenavigators.component';
import { BookingComponent } from './booking/booking.component';
import { SavebookingComponent } from './savebooking/savebooking.component';
import { BookednavigatorComponent } from './bookednavigator/bookednavigator.component';
import { UpdateNavigatorComponent } from './update-navigator/update-navigator.component';


const routes: Routes = [
  {path:'service',component:ServiceComponent},
  {path:'home',component:HomeComponent},
  {path:'about',component:AboutusComponent},
  {path:'contact',component:ContactComponent},
  {path:'signup',component:SignupComponent},
  {path:'addnavigator',component:AddNavigatorComponent},
  {path:'allnavigators',component:AllnavigatorsComponent},
  {path:'avilablenavigators',component:AvilablenavigatorsComponent},
  {path:'booking',component:BookingComponent},
  {path:'savanavigator/:navigatorId',component:SavebookingComponent},
  {path:'currentbookednavigator/:conformation',component:BookednavigatorComponent},
  {path:'update/:navigatorId',component:UpdateNavigatorComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
