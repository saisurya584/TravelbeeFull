import { Navigators } from './navigators';

describe('Navigators', () => {
  it('should create an instance', () => {
    expect(new Navigators()).toBeTruthy();
  });
});
