export interface AuthenticationResponse {
    
        token: string;
        message: string | boolean;
      }

