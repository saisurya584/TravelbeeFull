import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrl: './service.component.css'
})
export class ServiceComponent {
  
  constructor(private route:Router){}
  scrollToTop()
  {
  this.route.navigate(['/home']);
  }

}
