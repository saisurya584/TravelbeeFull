import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvilablenavigatorsComponent } from './avilablenavigators.component';

describe('AvilablenavigatorsComponent', () => {
  let component: AvilablenavigatorsComponent;
  let fixture: ComponentFixture<AvilablenavigatorsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AvilablenavigatorsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AvilablenavigatorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
