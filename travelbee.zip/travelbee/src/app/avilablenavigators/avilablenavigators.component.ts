import { Component } from '@angular/core';
import { NavigatorDto } from '../navigator';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NavigatorService } from '../navigator.service';
import { AuthService } from '../auth.service';


@Component({
  selector: 'app-avilablenavigators',
  templateUrl: './avilablenavigators.component.html',
  styleUrl: './avilablenavigators.component.css'
})
export class AvilablenavigatorsComponent {

  navigators: NavigatorDto[] = [];
  searchForm: FormGroup;
  email: string = '';
  places: string[] = []; // Array to hold places
   
  constructor(
    private route: ActivatedRoute,
    private navigatorService: NavigatorService,
    private router: Router,
    private formBuilder: FormBuilder,
    private authService: AuthService
  ) {
    this.searchForm = this.formBuilder.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      place: ['', Validators.required],
    });
  // Fetch places when the component initializes
  this.getAllPlaces();
    // Subscribe to changes in query parameters
    this.route.queryParams.subscribe(params => {
      this.email = params['email'] || ''; // Set the email property based on the query parameter
    });
  }
  ngOnInit(): void {
    // Initial state, no search performed
    this.showTable = false;
    this.showNoNavigatorsMessage = false;
   
  }
  getAllPlaces() {
    console.log("hello surya")
      this.navigatorService.getAllPlaces().subscribe(
        (data) => {
          this.places = data || []; // Assuming data is an array of strings
        },
        (error) => {
          console.error('Error fetching places:', error);
        }
      );
    
  }
  searchNavigators() {
    if (this.searchForm.valid) {
      const startDate = this.searchForm.get('startDate')?.value;
      const endDate = this.searchForm.get('endDate')?.value;
      const place = this.searchForm.get('place')?.value;
   
      this.navigatorService.getAvailableNavigators(startDate, endDate, place).subscribe(
        (data) => {
          this.navigators = data || [];
          this.showTable = this.navigators.length > 0;
          this.showNoNavigatorsMessage = !this.showTable;
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }
   
  bookNavigator(id: number) {
      const startDate = this.searchForm.get('startDate')?.value;
    const endDate = this.searchForm.get('endDate')?.value;
   
    this.router.navigate(['savanavigator', id],{queryParams: { startDate, endDate ,email: this.email},skipLocationChange: true });
  }
  //{ skipLocationChange: true }
  // Variables for conditions
  showTable: boolean = false;
  showNoNavigatorsMessage: boolean = false;
   
  navigateToMyBookings() {
    // Navigate to mybookings route with email as a query parameter
    this.router.navigate(['booking'], { queryParams: { email: this.email } ,skipLocationChange: true});
  }
  logout(): void {
    this.authService.logout();
    this.router.navigate(["home"]);
  }}


