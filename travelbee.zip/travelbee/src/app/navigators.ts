import { BookingDto } from "./navigator";

export class Navigators {
    navigatorId: number=0;
    place: string='';
    navigatorName: string='';
    navigatorEmail: string='';
    contactNumber: string='';
    aadharNumber: string='';
    price: number=0;
    status: boolean=false;
    photo: string=''; // Assuming the photo is a base64 string
    booking: BookingDto[] | undefined;
}
