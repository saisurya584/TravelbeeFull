// navigator.model.ts

export interface NavigatorDto {
    navigatorId: number;
    place: string;
    navigatorName: string;
    navigatorEmail: string;
    contactNumber: string;
    aadharNumber: string;
    price: number;
    status: boolean;
    photo: string; // Assuming the photo is a base64 string
    bookings: BookingDto[];
  }
  
  export interface BookingDto {
    bookingId: number;
    startDate: string; 
    endDate: string; 
    touristFullName: string;
    contactNumber: string;
    touristEmail: string;
    numOfAdults: number;
    numOfChildren: number;
    totalNumOfTourists: number;
    bookingConfirmationCode: string;
    navigatorDto: NavigatorDto;
  }
  
