import { Component } from '@angular/core';
import { NavigatorDto } from '../navigator';
import { NavigatorService } from '../navigator.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-allnavigators',
  templateUrl: './allnavigators.component.html',
  styleUrl: './allnavigators.component.css'
})
export class AllnavigatorsComponent {
  
  alertWithSucess()
  {
    Swal.fire("Deleted",'Deleted sucessfully','success');
  }
  photo:any;
  navigators: NavigatorDto[] = [];
  src:any;
 constructor(private navigatorService: NavigatorService, private router:Router,private authService: AuthService) {}

 ngOnInit(): void {
   this.navigatorService.getAllNavigators().subscribe(
     (response) => {
       console.log(response)
       this.navigators = response;
     },
     (error) => {
       console.error(error);
     }
   );
 }
updateNavigator(Id:number){
  console.log("hello")
 this.router.navigate(["update",Id] );

 }
deleteNavigator(Id:number){
 this.navigatorService.deleteNavigator(Id).subscribe(data=>{
   console.log(data);
   this.navigatorService.getAllNavigators().subscribe(
     (response) => {
       console.log(response)
       this.navigators = response;
       this.alertWithSucess();
     },
     (error) => {
       console.error(error);
     }
   );
 })

 }

navigatorDetails(Id:number){
 this.router.navigate(["navigatordetails",Id],{skipLocationChange: true });

}
addNavigator(){
 this.router.navigate(["addnavigator"],{skipLocationChange: true });

}
logout(): void {
 this.authService.logout();
 this.router.navigate(["login"]);
}
scrollToTop()
{
this.router.navigate(['/addnavigator']);
}

}


