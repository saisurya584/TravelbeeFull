import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllnavigatorsComponent } from './allnavigators.component';

describe('AllnavigatorsComponent', () => {
  let component: AllnavigatorsComponent;
  let fixture: ComponentFixture<AllnavigatorsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AllnavigatorsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AllnavigatorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
