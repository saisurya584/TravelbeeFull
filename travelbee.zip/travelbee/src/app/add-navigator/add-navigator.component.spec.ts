import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddNavigatorComponent } from './add-navigator.component';

describe('AddNavigatorComponent', () => {
  let component: AddNavigatorComponent;
  let fixture: ComponentFixture<AddNavigatorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddNavigatorComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddNavigatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
