import { Component } from '@angular/core';
import { NavigatorService } from '../navigator.service';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-navigator',
  templateUrl: './add-navigator.component.html',
  styleUrl: './add-navigator.component.css'
})
export class AddNavigatorComponent {
  photo: File | null = null;
  place: string = '';  
  navigatorName: string = '';
  navigatorEmail: string = '';
  contactNumber: string = '';
  aadharNumber: string = '';
  price: number = 0;
  successMessage: string | null = null;
  errorMessage: string | null = null;

  isName=false;
  isEmail=false;
  iscontact=false;
  isAadhar=false;
  isPlace=false;
  isPrice=false;
  
  alertWithSucess()
    {
      Swal.fire("Thank you..",'Navigator added successfully','success');
    }
  constructor(private navigatorService: NavigatorService,private router: Router,private authService:AuthService) {}
  
  ngOnInit() {
    // Initialize any additional properties if needed
  }
  
  onFileChange(event: any) {
    const files = event.target.files;
    if (files && files.length > 0) {
      this.photo = files[0];
    }
  }
  
  onSubmit(form: any) {
    console.log(form)
    if(!this.navigatorName.match("[A-Za-z]{4,20}"))
    {
       this.isName=true;
    }

    if(!this.navigatorEmail.match("[A-Za-z]{4,20}@gmail.com"))
    {
       this.isEmail=true;
    }
    if(!this.contactNumber.match("[8976]+[0-9]{9,11}"))
    {
       this.iscontact=true;
    }
    if(!this.aadharNumber.match("[2-9]+[0-9]{11}"))
    {
       this.isAadhar=true;
    }
    if(!this.place.match("[A-Za-z]{4,20}"))
    {
       this.isPlace=true;
    }
    
    if (form.valid && this.photo) {
      const formData = new FormData();
      formData.append('photo', this.photo);
      formData.append('place', this.place);
      formData.append('navigatorName', this.navigatorName);
      formData.append('navigatorEmail', this.navigatorEmail);
      formData.append('contactNumber', this.contactNumber);
      formData.append('aadharNumber', this.aadharNumber);
      formData.append('price', this.price.toString());
  
      this.navigatorService.addNavigator(formData).subscribe(
        (response) => {
          console.log(response);
          this.alertWithSucess();
          this.errorMessage = null;
        },
        (error) => {
          console.error(error);
          this.successMessage = null;
          this.errorMessage = 'Error adding navigator';
        }
      );
    }
  }
  
  
    navigateToAllNavigators() {
      this.router.navigate(['allnavigators'],{skipLocationChange: true });
    }

  logout(): void {
    this.authService.logout();
    this.router.navigate(["home"]);
   }

}


